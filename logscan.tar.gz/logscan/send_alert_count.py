# -*-coding:utf-8-*-
# crontab 发送前一天项目error 行数至钉钉群

import yaml
import requests
import datetime
import json

alert_count_csv = '/tmp/alert_count_csvs/%s.csv' % (datetime.datetime.now() - datetime.timedelta(days=1)).strftime('%Y-%m-%d')
alert_count_map = {}
for line in open(alert_count_csv, 'r'):
    if line:
        project_name, alert_count = line.split(',')
        alert_count_map[project_name] = alert_count

# print alert_count_map
yaml_data = yaml.load(open('dingding_url_cfg.yaml'))
for url, projects in yaml_data.items():
    count_list = [[project, alert_count_map[project]] for project in projects if project in alert_count_map]
    count_list = sorted(count_list, key=lambda x: int(x[1]), reverse=True)
    content = ''.join([' : '.join(i) for i in count_list])
    # url = 'https://oapi.dingtalk.com/robot/send?access_token=93edbeba93c353a1367823eba1aa9c354e61242a5c6c9bf442a789212aa311c0'
    title = '#  %s 项目日志<ERROR>行数 #' % (datetime.datetime.now() - datetime.timedelta(days=1)).strftime('%Y-%m-%d')
    headers = {'content-type': 'application/json'}
    payload = {
        "msgtype": "text",
        "text": {
            "content": "%s\n\n%s\n" % (title, content)
        },
        "at": {
            "atMobiles": [
            ],
            "isAtAll": True
        }
    }
    requests.packages.urllib3.disable_warnings()
    ret = requests.post(url, data=json.dumps(payload), headers=headers)
    print url, ret.json()