#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Author: zhuima
# zhuima @ 2016-03-24 15:18:13
# Function: send message by wechat api


import warnings

with warnings.catch_warnings():
    warnings.filterwarnings("ignore",category=DeprecationWarning)
    import sys
    import urllib2
    import time
    import json
    import requests

reload(sys)
sys.setdefaultencoding('utf-8')

#hname = sys.argv[1]
#title = sys.argv[2]
#content = sys.argv[3]


class Token(object):
    def __init__(self, corpid, corpsecret):
        self.baseurl = 'https://qyapi.weixin.qq.com/cgi-bin/gettoken?corpid={0}&corpsecret={1}'.format(corpid, corpsecret)
        self.expire_time = sys.maxint

    def get_token(self):
        if self.expire_time > time.time():
            requests.packages.urllib3.disable_warnings()
            request = urllib2.Request(self.baseurl)
            response = urllib2.urlopen(request)
            ret = response.read().decode('utf-8').strip()
            ret = json.loads(ret)
            if 'errcode' in ret.keys():
                print >> ret['errmsg'], sys.stderr
                sys.exit(1)
            self.expire_time = time.time() + ret['expires_in']
            self.access_token = ret['access_token']
        return self.access_token


def send_msg(secret, id, hname, title, now, content):
    """修改id 和secret """
    corpid = ""
    corpsecret = ""
    qs_token = Token(corpid=corpid, corpsecret=corpsecret).get_token()
    url = "https://qyapi.weixin.qq.com/cgi-bin/message/send?access_token={0}".format(
        qs_token)
    headers = {'Content-Type': 'application/json', "charset": "utf-8"}
    payload = {
        "touser": "@all",
        "msgtype": "text",
        "agentid": "{0}".format(id),
        "text": {
                   "content": "主机: {0}\n项目: {1}\n当前时间: {2} \n内容: {3}".format(hname, title, now, content)
        },
        "safe": "0"
    }
    requests.packages.urllib3.disable_warnings()
    ret = requests.post(url, data=json.dumps(payload, ensure_ascii=False))

    print ("".join("{0}-{1}".format(hname, title)), now, ret.json())
    return ret.json()


if __name__ == '__main__':
    #print title, content
    now = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    send_msg(hname, title, now, content)
