#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Author: zhuima
# zhuima @ 2016-03-24 15:18:13
# Function: send message by email api


import smtplib
import traceback 
from email.mime.text import MIMEText
mail_host="smtp.263.net"
mail_user="script@yunniao.me"
mail_pass=""


#mailto_list = ['zhangchangan@yunniao.me']


def send_mail(mailto_list, title, sub, content):
    me="<"+mail_user+">"
    msg = MIMEText(content,_subtype='plan',_charset='utf8')
    msg['Subject'] = sub
    msg['From'] = title
    msg['To'] = ";".join(mailto_list)
    try:
        s = smtplib.SMTP()
        s.connect(mail_host)
        s.login(mail_user,mail_pass)
        s.sendmail(me, mailto_list, msg.as_string())
        s.close()
        return True
    except Exception, e:
        print "zuimais fuck {0}".format(str(e))
        traceback.print_exc() 
        return False



#import sys
#title = sys.argv[1]
#sub = sys.argv[2]
#content = sys.argv[3]
#
#print mailto_list
#send_mail(mailto_list, title, sub, content)
