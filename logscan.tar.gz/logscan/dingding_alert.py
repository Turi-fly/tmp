#!/usr/bin/env python
# -*- coding: utf-8 -*-

import json
import sys
import requests
from dingding_url_map import url_map

reload(sys)
sys.setdefaultencoding('utf-8')

def send_msg(title, content):
    '''
    if you want use this script in another env, Please change the sys
    Maybe you only need sys.argv[1] and sys.argv[2]
    use replace funcation to split line
    '''
    # logscan
    pname = '_'.join(title.split('_')[:-1])
    print pname
    if len(content) > 4700:
        content = content[:4700] + '...'

    try:
        url = url_map[pname]
        print url
    except Exception, e:
        url = ''
    headers = {'content-type': 'application/json'}
    payload = {
        "msgtype": "text",
        "text": {
            "content": "标题:{0}\n内容:{1}\n".format(title, content)
        },
        "at": {
            "atMobiles": [
            ],
            "isAtAll": True
        }
    }
    print url
    requests.packages.urllib3.disable_warnings()
    ret = requests.post(url, data=json.dumps(payload), headers=headers)
    print pname, ret.json()


if __name__ == '__main__':
    title = sys.argv[1]
    content = sys.argv[2]
    send_msg(title, content)
