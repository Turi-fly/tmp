#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
import glob
import datetime
import time
import threading
import yaml
import multiprocessing
from smail import send_mail
from matcher import Scan
from logtemplate import logger
from dingding_alert import send_msg
from write_alert_log import write_alert_num


def get_result(logfile):
    '''get email subject and content'''
    if len(logfile.split('/')) == 5:
    	pname = "{0}_{1}".format(logfile.split('/')[3], logfile.split('/')[-1])
        print(pname)
    if len(logfile.split('/')) == 6: 
    	pname = "{0}-{1}_{2}".format(logfile.split('/')[3], logfile.split('/')[4], logfile.split('/')[-1])
        print(pname)
    lock.acquire()
    content = Scan(logfile, pname).match()
    lock.release()
    if isinstance(content, str) and len(content) > 1:
        send_msg(pname, content)
    write_alert_num(pname, content.count('\n') if isinstance(content, str) else 0)


def main():
    '''mutil send message'''
    now = datetime.datetime.now().strftime("%Y%m%d")
    loglist = [ dir for dir in glob.glob('/mnt/logs/*/error.log')] + [ dir for dir in glob.glob('/mnt/logs/*/*/error.log')]
    print(loglist)
    start = time.clock()
    threads = []
    for logfile in loglist:
        t = threading.Thread(target=get_result, args=(logfile, ), name=logfile)
        threads.append(t)

    for t in threads:
        t.start()

    for t in threads:
        t.join()

    time.sleep(30)

def write_dingding_url_map():
    ''' write dingging url map'''
    yaml_data = yaml.load(open('dingding_url_cfg.yaml'))
    with open('dingding_url_map.py', 'w') as mapfile:
        url_map = {}
        for url,projects in yaml_data.items():
            for project in projects:
                url_map[project] = url
        mapfile.write('url_map = %s' % url_map)

if __name__ == "__main__":
    write_dingding_url_map()
    lock = threading.Lock()
    while 1:
        main()
