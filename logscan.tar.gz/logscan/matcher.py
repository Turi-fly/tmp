#!/usr/bin/env python
# -*- coding: utf-8 -*-
'''
1. 获取文件当前position,然后和数据库里取出来的值对比
2. 读取position片段的日志进行正则匹配，如果匹配返回，如果不匹配就跳过
'''

import os
import re
import threading
from  os.path import getsize
from shelvewrite import Counter
from logtemplate import logger
from re import compile, IGNORECASE
import traceback

#pattern = compile(r'Faild|Error|exception|\bat\b',IGNORECASE)
pattern = compile(r'.ERROR', re.M)

DB_DIR = os.path.abspath(os.path.dirname(__file__))


class Scan(object):
    """docstring for Matcher"""
    def __init__(self, logfile, pname):
        super(Scan, self).__init__()
        self.counter = Counter(os.path.join(DB_DIR, 'hupo'))
        self.logfile = logfile
        self.pname  = pname
        self.lock = threading.Lock()

    def match(self):
        messages = []
        data = open(self.logfile, 'r')
        try:
            last = self.counter.get(self.pname)
            now = getsize(self.logfile)
            logger.debug("{0} file last point is {1}".format(self.logfile, last))
            logger.debug("{0} file now point is {1}".format(self.logfile, now))
            if now < last :
                data.seek(0)
            if now > last:
                data.seek(last)
            if now == last:
                data.seek(now)

        except Exception, e:
            logger.error(e, exc_info=True)

        for line in data:
            if pattern.search(line):
                if "Required String parameter 'txnId' is not present" in line or "error: 500016" in line:
		     continue
                if "账户不存在或无效" in line:
                     continue
                if "Sign error" in line:
                     continue
                if "wallet/transaction" in line:
		     continue
                if "过期" in line:
                     continue
                if "被冻结" in line:
                     continue
                if "钱包账户状态不允许此操作" in line:
                     continue
		else:
                     messages.append(line)
        logger.debug("把{0}的postion写进shelve: {1}".format(self.logfile, data.tell()))
        self.counter.set(self.pname, data.tell())
        self.counter.stop()
        data.close()
        return ''.join(messages)
