#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Author: zhuima
# zhuima @ 2016-03-24 15:18:13
# Function: Scan log and write in file

'''
1. 使用shevle模块进行文件位置的持久化
2. 对写文件进行锁操作，避免遗漏或串写
'''


import shelve
import threading
from logtemplate import logger


class Counter(object):
    """docstring for Checker"""
    def __init__(self, dbfile):
        super(Counter, self).__init__()
        self.dbfile = dbfile
        self.db = shelve.open(dbfile, 'c')
        self.lock = threading.Lock()
        self.stopped = False

    def set(self, name, position):
        with self.lock:
            logger.debug("{0} 本次position {1}".format(name, position))
            self.db[name] = position
            self.db.sync()

    def get(self, name):
        with self.lock:
            last_position = self.db.get(name, 0)
            return last_position

    def stop(self):
        with self.lock:
            if not self.stopped:
                self.db.close()
