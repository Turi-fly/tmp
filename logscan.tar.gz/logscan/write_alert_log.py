#!/usr/bin/env python
import os
def write_alert_num(pname, lines):
    project_name = '_'.join(pname.split('_')[:-1])
    logpath1 = '/tmp/alert_lines_logs/%s.log' % project_name
    with open(logpath1, 'w') as logfile1:
        logfile1.write(str(lines))

    logpath2 = '/tmp/alert_count_logs/%s.log' % project_name
    if lines:
        with open(logpath2, 'a') as logfile2:
            logfile2.write('1' * lines)
        return
    if not os.path.exists(logpath2):
        os.system('touch %s' % logpath2)