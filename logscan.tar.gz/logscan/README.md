日志轮询检测错误关键字机制
=========================


### 一、项目介绍


    logtemplate.py 	日志模版
    matcher.py		关键字匹配
    shelvewrite.py	持久化文件读取位置
    plogscan.py		真正入口文件

    schat.py		微信告警 已废弃
    smail.py		邮件通知 已废弃
    dingding_alert.py	钉钉高警

    dingding_url_cfg.yaml  钉钉报警接口配置（手动配置）
    dingding_url_map.py    钉钉报警接口，项目=>url键值对（程序生成）

    alert_count_csv.py     统计报警行数至csv
    send_alert_count.oy    发送报警行数统计至钉钉群

### 二、说明
    1、使用glob模块获取目录下包含当天日期的所有日志，组成一个大的list
    2、使用多线程读取日志文件，获取日志的position，然后记录到shelve文件中去
    3、下次再次读取文件的时候拿上次存储的position和当前的对比，取其值进行行遍历，然后捕获关键字
    4、判断获取内容长度，根据title获取对应钉钉报警接口，触发钉钉报警
