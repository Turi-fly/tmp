#!/usr/bin/env python
# -*- coding: utf-8 -*-
# crontab 收集前一天项目error 行数至csv文件
import glob
import datetime
import commands

alert_count_csv = '/tmp/alert_count_csvs/%s.csv' % (datetime.datetime.now() - datetime.timedelta(days=1)).strftime('%Y-%m-%d')
alert_count_logs = sorted(glob.glob('/tmp/alert_count_logs/*.log'))
with open(alert_count_csv, 'w+') as csv:
    for log in alert_count_logs:
        count = commands.getoutput("wc -c %s | awk -F ' ' '{print $1}'" % log)
        project_name = log.split('/')[-1].split('.')[0]
        csv.write('%s,%s\n' % (project_name, count))
        commands.getoutput("> %s" % log)
